import streamlit as st
from agent import Agent
from data_manager import DataManager
from ui_components import initial_setup, display_chat_history, file_uploader_and_profiling

# -----------------------------------------------------------
# 🔧 PROCESSING USER PROMPTS (Modular Function)
# -----------------------------------------------------------
def process_prompt(user_prompt: str, agent: Agent, data_manager: DataManager):
    """Handles the logic for processing a user prompt."""
    st.session_state.chat_history.append({"role": "user", "content": user_prompt})
    with st.chat_message("user"):
        st.markdown(user_prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            routed_request = agent.route_request(user_prompt)
            tool = routed_request.get("tool", "sql_generator") if routed_request else "sql_generator"

            # --- SQL Query Generation ---
            if tool == "sql_generator":
                schema = data_manager.get_schema_string()
                query = agent.generate_sql(user_prompt, schema, data_manager.table_name, st.session_state.chat_history)

                if not query:
                    response = {"role": "assistant", "content": "Sorry, I couldn't generate a SQL query for that."}
                else:
                    result_df, error = data_manager.execute_query(query)

                    if error:
                        suggestions = agent.analyze_error(query, error, schema)
                        if suggestions:
                            response = {
                                "role": "assistant",
                                "content": "I encountered an issue with that query. Here are a few options:",
                                "error_message": f"Error: {error}",
                                "error_suggestions": suggestions
                            }
                        else:
                            response = {
                                "role": "assistant",
                                "content": f"Query failed with an unrecoverable error: {error}",
                                "sql": query
                            }
                    else:
                        summary = agent.interpret_results(user_prompt, query, result_df)
                        charts = agent.suggest_charts(result_df)
                        follow_ups = agent.suggest_follow_ups(user_prompt, result_df)
                        response = {
                            "role": "assistant",
                            "content": summary,
                            "dataframe": result_df,
                            "sql": query,
                            "charts": charts,
                            "chart_df": result_df,
                            "follow_ups": follow_ups
                        }

            # --- Non-SQL (greetings / general queries) ---
            else:
                response = {"role": "assistant", "content": "Hello! How can I help you with your data today?"}

            st.session_state.chat_history.append(response)

# -----------------------------------------------------------
# ⚙️ MAIN APPLICATION
# -----------------------------------------------------------
def main():
    """Main function to run the Streamlit app."""
    initial_setup()

    st.title("🚀 Unified AI Data Agent")
    st.write("Smarter, interactive, and proactive — with memory, clarifications, and adaptive retries.")

    # --- Initialize Agent & Data Manager ---
    if st.session_state.agent is None:
        try:
            st.session_state.agent = Agent()
        except Exception:
            st.error("Please provide your GROQ_API_KEY in .streamlit/secrets.toml")
            st.stop()

    if st.session_state.data_manager is None:
        st.session_state.data_manager = DataManager()

    if "user_choice" not in st.session_state:
        st.session_state.user_choice = None

    agent = st.session_state.agent
    data_manager = st.session_state.data_manager

    # --- Sidebar Controls ---
    with st.sidebar:
        st.header("⚙️ Controls")
        file_loaded = file_uploader_and_profiling(data_manager)
        if file_loaded:
            col1, col2 = st.columns(2)
            with col1:
                st.button("Undo", disabled=(st.session_state.current_df_index <= 0), on_click=data_manager.undo)
            with col2:
                st.button("Redo", disabled=(st.session_state.current_df_index >= len(st.session_state.df_states) - 1), on_click=data_manager.redo)

    # --- Main View ---
    if not file_loaded:
        st.info("📁 Please upload a CSV or Excel file in the sidebar to begin.")
        st.stop()

    st.dataframe(data_manager.get_current_df())

    # -----------------------------------------------------------
    # 🧩 Handle user's fix/clarification choice (smart retry)
    # -----------------------------------------------------------
    if st.session_state.user_choice:
        choice = st.session_state.user_choice
        st.session_state.user_choice = None  # Reset after handling

        suggestion = choice.get("suggestion")
        message_index = choice.get("message_index", len(st.session_state.chat_history) - 1)

        # Find the original user query
        original_prompt = ""
        for i in range(message_index, -1, -1):
            if st.session_state.chat_history[i]["role"] == "user":
                original_prompt = st.session_state.chat_history[i]["content"]
                break

        # --- Clarification Strategy ---
        if suggestion.get("strategy") == "ASK_USER_CLARIFICATION":
            response = {"role": "assistant", "content": "Could you please provide more details or clarify your request?"}
            st.session_state.chat_history.append(response)

        # --- Retry with Fix Strategy ---
        else:
            with st.chat_message("assistant"):
                with st.spinner("Applying solution and retrying..."):
                    schema = data_manager.get_schema_string()
                    new_query = agent.regenerate_query_with_solution(
                        original_prompt, suggestion, schema, data_manager.table_name, st.session_state.chat_history
                    )

                    if new_query:
                        result_df, error = data_manager.execute_query(new_query)
                        if error:
                            response = {
                                "role": "assistant",
                                "content": f"The fix also failed. Error: {error}",
                                "sql": new_query
                            }
                        else:
                            summary = agent.interpret_results(original_prompt, result_df)
                            charts = agent.suggest_charts(result_df)
                            follow_ups = agent.suggest_follow_ups(original_prompt, result_df)
                            response = {
                                "role": "assistant",
                                "content": summary,
                                "dataframe": result_df,
                                "sql": new_query,
                                "charts": charts,
                                "chart_df": result_df,
                                "follow_ups": follow_ups
                            }
                    else:
                        response = {"role": "assistant", "content": "I wasn't able to apply the fix successfully."}

                    st.session_state.chat_history.append(response)

        st.rerun()

    # -----------------------------------------------------------
    # 💬 Display chat history and take new input
    # -----------------------------------------------------------
    display_chat_history()

    user_prompt = st.chat_input("Ask a question about your data...")
    if user_prompt:
        process_prompt(user_prompt, agent, data_manager)
        st.rerun()

# -----------------------------------------------------------
# 🚀 Run App
# -----------------------------------------------------------
if __name__ == "__main__":
    main()
